# JAWARA SISTEM LEAGUE — Android wrapper

Project ini adalah kerangka aplikasi Android yang membuka aplikasi web JAWARA SISTEM LEAGUE yang sudah di-host di Netlify. Database dan API tetap online; APK tidak menyimpan database liga secara lokal.

## URL aplikasi
Saat ini mengarah ke:
`https://tangerine-pasca-fea014.netlify.app/`

Pastikan versi web terbaru sudah berhasil Published di Netlify sebelum APK dibangun.

## Cara membangun APK
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Buka folder `JawaraSistemLeagueAndroid` melalui Android Studio.
3. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Build Tools yang direkomendasikan.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Untuk APK release yang dibagikan, gunakan **Build > Generate Signed Bundle / APK** dan buat keystore sendiri. Simpan keystore dan password dengan aman.

## Catatan
- Ini source project Android, bukan file APK yang sudah dikompilasi.
- Login, database, dan fitur aplikasi bergantung pada layanan online dan koneksi internet.
- Bila domain Netlify berubah, ubah `APP_URL` dan daftar domain di `MainActivity.java`.
