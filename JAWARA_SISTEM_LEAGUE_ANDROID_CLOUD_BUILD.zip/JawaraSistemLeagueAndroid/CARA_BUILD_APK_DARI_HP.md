# Cara membangun APK JAWARA SISTEM LEAGUE hanya dengan HP Android

ZIP ini adalah **source project + workflow cloud build**, bukan file APK jadi. GitHub Actions akan mengompilasi APK di server GitHub, sehingga tidak perlu PC atau Android Studio.

## Langkah 1 — Buat repository GitHub
1. Buka https://github.com di Chrome HP dan login/daftar.
2. Tekan `+` → `New repository`.
3. Isi nama `jawara-sistem-league-android`.
4. Pilih **Public** (paling mudah untuk memakai GitHub Actions gratis) atau Private jika akun/kuota Actions Anda mendukungnya.
5. Buat repository.

## Langkah 2 — Upload file project
1. Ekstrak ZIP ini menggunakan aplikasi pengelola file HP.
2. Buka repository yang baru dibuat di Chrome.
3. Pilih **Add file → Upload files**.
4. Upload semua isi folder project (termasuk folder `.github/workflows`). Jika tampilan mobile tidak menampilkan opsi ini, aktifkan **Situs desktop** pada menu Chrome.
5. Tekan **Commit changes**.

## Langkah 3 — Tunggu build
1. Buka tab **Actions** di repository.
2. Pilih workflow **Build Jawara Sistem League APK**.
3. Tunggu sampai status hijau **Success**. Build pertama bisa memerlukan beberapa menit.
4. Buka hasil run terbaru, gulir ke **Artifacts**, lalu unduh `JAWARA-SISTEM-LEAGUE-APK`.
5. ZIP artifact itu berisi `app-debug.apk`. Ekstrak lalu buka APK untuk memasang. Jika Android bertanya, izinkan Chrome/pengelola file memasang aplikasi dari sumber ini.

## Catatan penting
- APK debug cocok untuk uji coba pribadi. Untuk distribusi resmi, buat APK release yang ditandatangani dengan keystore milik Anda dan simpan keystore/password dengan aman.
- APK ini membuka web app Netlify yang dikonfigurasi di source. Login, data, dan fitur tetap bergantung pada server dan koneksi internet.
- Periksa URL `APP_URL` di `app/src/main/java/id/jawara/sistemleague/MainActivity.java` sebelum build. Saat ini diarahkan ke `https://tangerine-pasca-fea014.netlify.app/`.
- Jangan pernah memasukkan password admin atau secret database ke repository.
